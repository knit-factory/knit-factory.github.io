---
title: Pets
layout: collection
permalink: /pets/
collection: pets
entries_layout: grid
classes: wide
---

Sample document listing for the collection `_pets`.
