---
title: "Post: Quote"
categories:
  - Post Formats
tags:
  - Post Formats
  - quote
---

> Only one thing is impossible for God: To find any sense in any copyright law on the planet.
  
> <cite><a href="http://www.brainyquote.com/quotes/quotes/m/marktwain163473.html">Mark Twain</a></cite>