---
title: Markup (grid view)
layout: tag
permalink: /tags/markup-grid/
taxonomy: markup
entries_layout: grid
---

Sample post listing for the tag `markup`.
